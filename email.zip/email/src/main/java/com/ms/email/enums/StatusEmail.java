package com.ms.email.enums;

public enum StatusEmail {
    SENT,
    ERROR;
}
