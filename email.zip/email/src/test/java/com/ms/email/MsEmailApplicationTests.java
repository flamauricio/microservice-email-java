package com.ms.email;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsEmailApplicationTests {

	@Test
	void contextLoads() {
	}

}
